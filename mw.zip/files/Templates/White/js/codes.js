	$(document).ready(function(){
		$(".boxes1").hide(); // Initially hide all content
	$("#tabs li:first").attr("id","current"); // Activate first tab
	$("#content div:first").fadeIn(); // Show first tab content
    $('#tabs a').click(function(e) {
        e.preventDefault();        
        $(".boxes1").hide(); //Hide all content
        $("#tabs li").attr("id",""); //Reset id's
        $(this).parent().attr("id","current"); // Activate this
        $('#' + $(this).attr('title')).fadeIn(); // Show content for current tab
    });
		$("#main_charge section:first").attr("class","active2");
		$("#oprator ul li:first").attr("class","active");
		$("#hamrah_avval").click(function(){
		$("#oprator ul li").removeClass("active");
		$("#main_charge section").removeClass("active2");
		$("#hamrah_avval").attr("class","active");
		$("#hamrah_avval_box").attr("class","active2");
		});
		$("#irancell").click(function(){
		$("#oprator ul li").removeClass("active");
		$("#main_charge section").removeClass("active2");
		$("#irancell").attr("class","active");
		$("#irancell_box").attr("class","active2");
		});
		$("#talia").click(function(){
		$("#oprator ul li").removeClass("active");
		$("#main_charge section").removeClass("active2");
		$("#talia").attr("class","active");
		$("#talia_box").attr("class","active2");
		});
		$("#rightel").click(function(){
		$("#oprator ul li").removeClass("active");
		$("#main_charge section").removeClass("active2");
		$("#rightel").attr("class","active");
		$("#rightel_box").attr("class","active2");
		});
	
	
	
	
	
	
	
	
	
	
	
	
		$("#operator2 ul li:first").attr("class","active3");
		$("#irancell_1 input").click(function(){
		$("#operator2 ul li").removeClass("active3");
		$("#irancell_1").attr("class","active3");
		});
		$("#mci_1 input").click(function(){
		$("#operator2 ul li").removeClass("active3");
		$("#mci_1").attr("class","active3");
		});
		$("#talia_1 input").click(function(){
		$("#operator2 ul li").removeClass("active3");
		$("#talia_1").attr("class","active3");
		});		
		$("#righ_1 input").click(function(){
		$("#operator2 ul li").removeClass("active3");
		$("#righ_1").attr("class","active3");
		});		


	
      $( function() {
        $('.image-filters').customradio({
          mobileImages: true,
		  imgsUrl: 'imgs/'
        });
      });
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36251023-1']);
  _gaq.push(['_setDomainName', 'jqueryscript.net']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
  
    $(".mtn_span").click(function(){
	        $(".active_mtn").removeClass("active_mtn");
			$(this).addClass("active_mtn");
    });
    $(".mci_span").click(function(){
	        $(".active_mci").removeClass("active_mci");
			$(this).addClass("active_mci");
    });
    $(".righ_span").click(function(){
	        $(".active_righ").removeClass("active_righ");
			$(this).addClass("active_righ");
    });
    $(".talia_span").click(function(){
	        $(".active_talia").removeClass("active_talia");
			$(this).addClass("active_talia");
    });
	
	
	
	
	
	
	$(".mtn_span input[type='radio']").click(function(){
	var x = $(".mtn_span input[type='radio']:checked").val();
		 $(".price_mtn_child").html(x);	
    });
	
		$(".mci_span input[type='radio']").click(function(){
	var m = $(".mci_span input[type='radio']:checked").val();
	
		$(".sharj_mci_box option").click(function(){
			var s = $(".sharj_mci_box option:selected").val();
	        sum = (m*s);
		 $(".price_mci_child").html(sum);
		});
    });
		$(".sharj_mci_box option").click(function(){
			var m = $(".sharj_mci_box option:selected").val();
			$(".mci_span input[type='radio']").click(function(){
				var s = $(".mci_span input[type='radio']:checked").val();
				sum = (m*s);
				$(".price_mci_child").html(sum);
		});
    });
	

		$(".talia_span input[type='radio']").click(function(){
	var g = $(".talia_span input[type='radio']:checked").val();
	
		$(".sharj_talia_box option").click(function(){
			var f = $(".sharj_talia_box option:selected").val();
	        sum = (f*g);
		 $(".price_talia_child").html(sum);
		});
    });
		$(".sharj_talia_box option").click(function(){
			var g = $(".sharj_talia_box option:selected").val();
			$(".talia_span input[type='radio']").click(function(){
				var f = $(".talia_span input[type='radio']:checked").val();
				sum = (g*f);
				$(".price_talia_child").html(sum);
		});
    });
	
	

		$(".righ_span input[type='radio']").click(function(){
	var k = $(".righ_span input[type='radio']:checked").val();
	
		$(".sharj_righ_box option").click(function(){
			var z = $(".sharj_righ_box option:selected").val();
	        sum = (k*z);
		 $(".price_righ_child").html(sum);
		});
    });
		$(".sharj_righ_box option").click(function(){
			var k = $(".sharj_righ_box option:selected").val();
			$(".righ_span input[type='radio']").click(function(){
				var z = $(".righ_span input[type='radio']:checked").val();
				sum = (k*z);
				$(".price_righ_child").html(sum);
		});
    });
	




		
		$(".sharj_mostaghim_box option").click(function(){
		var d = $(this).val();
		$(".price_moshtaghim_child").html(d);
		});

		    $(".wimax_span").click(function(){
	        $(".active_wimax_span").removeClass("active_wimax_span");
			$(this).addClass("active_wimax_span");
    });
		
		
		
				$("#slider").hover(function(){
				var x = $(this).val();
				$(".price_wimax_child2").html(x);
		});
		
		
		
		
		

$('.persianumber').persiaNumber();
$('body').persiaNumber();
$('.xdsoft_slider_label').persiaNumber();

		
		
});